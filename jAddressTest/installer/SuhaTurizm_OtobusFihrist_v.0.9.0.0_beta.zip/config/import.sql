INSERT INTO `Authority` VALUES (1, 'Admin');
INSERT INTO `Authority` VALUES (2, 'User');
INSERT INTO `Users` VALUES (1, 'admin','YWRtaW4=','admin','admin','5551221229',1);
INSERT INTO `Users` VALUES (2, 'user','dXNlcg==','user','user','5551221239',2);